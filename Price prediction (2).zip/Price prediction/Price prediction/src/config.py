TRAINING_DATA='data/processed/zillow_Cleveland_clean.pkl'
TRAINING_DATA_FOLDS='data/processed/zillow_Cleveland_clean_folds.pkl'
MODEL_OUTPUT='models/'
PREPROCESSOR='preprocessor_v2'