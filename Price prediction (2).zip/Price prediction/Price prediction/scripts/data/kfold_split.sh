#!/bin/bash
python src/kfold_split.py