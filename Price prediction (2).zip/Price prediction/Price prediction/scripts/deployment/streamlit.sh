#!/bin/bash
streamlit run src/streamlit.py
echo "Streamlit app running on localhost:8501"